package cn.com.flaginfo.dao;

import cn.com.flaginfo.pojo.Solu2Collect;

public interface Solu2CollectMapper {
    int deleteByPrimaryKey(String id);

    int insert(Solu2Collect record);

    int insertSelective(Solu2Collect record);

    Solu2Collect selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Solu2Collect record);

    int updateByPrimaryKey(Solu2Collect record);
}