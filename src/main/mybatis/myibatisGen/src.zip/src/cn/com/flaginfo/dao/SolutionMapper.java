package cn.com.flaginfo.dao;

import cn.com.flaginfo.pojo.Solution;

public interface SolutionMapper {
    int deleteByPrimaryKey(String id);

    int insert(Solution record);

    int insertSelective(Solution record);

    Solution selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Solution record);

    int updateByPrimaryKey(Solution record);
}