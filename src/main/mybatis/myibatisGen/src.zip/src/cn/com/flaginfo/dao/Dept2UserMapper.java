package cn.com.flaginfo.dao;

import cn.com.flaginfo.pojo.Dept2User;

public interface Dept2UserMapper {
    int insert(Dept2User record);

    int insertSelective(Dept2User record);
}