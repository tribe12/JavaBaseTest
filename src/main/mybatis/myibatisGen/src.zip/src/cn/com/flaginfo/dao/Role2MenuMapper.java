package cn.com.flaginfo.dao;

import cn.com.flaginfo.pojo.Role2Menu;

public interface Role2MenuMapper {
    int insert(Role2Menu record);

    int insertSelective(Role2Menu record);
}