package cn.com.flaginfo.dao;

import cn.com.flaginfo.pojo.Role2User;

public interface Role2UserMapper {
    int insert(Role2User record);

    int insertSelective(Role2User record);
}