package cn.com.flaginfo.dao;

import cn.com.flaginfo.pojo.PersonHonour;

public interface PersonHonourMapper {
    int deleteByPrimaryKey(String id);

    int insert(PersonHonour record);

    int insertSelective(PersonHonour record);

    PersonHonour selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(PersonHonour record);

    int updateByPrimaryKey(PersonHonour record);
}