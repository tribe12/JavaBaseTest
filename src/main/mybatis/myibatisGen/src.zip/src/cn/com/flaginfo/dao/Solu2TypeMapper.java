package cn.com.flaginfo.dao;

import cn.com.flaginfo.pojo.Solu2Type;

public interface Solu2TypeMapper {
    int insert(Solu2Type record);

    int insertSelective(Solu2Type record);
}